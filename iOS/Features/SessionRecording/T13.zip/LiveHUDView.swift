// [協作區] LiveHUDView.swift
// 用途：呈現騎乘中的滿版 Live HUD、即時指標、迷你路線與滑動結束控制。
// 委派至：useSessionRecording 提供狀態與 actions；Fall Alert UI 保留至 Task-014。

import Foundation
import SwiftUI

struct LiveHUDView: View {
    @ObservedObject var sessionRecording: SessionRecordingViewModel

    var body: some View {
        GeometryReader { proxy in
            let topPadding = proxy.safeAreaInsets.top + 12
            let bottomPadding = proxy.safeAreaInsets.bottom + 14
            let horizontalPadding: CGFloat = 20
            let dockHeight: CGFloat = 96

            ZStack(alignment: .bottom) {
                liveBackground
                    .frame(width: proxy.size.width, height: proxy.size.height)
                    .ignoresSafeArea()

                ScrollViewReader { reader in
                    ScrollView(showsIndicators: false) {
                        VStack(spacing: 16) {
                            Color.clear
                                .frame(height: 0)
                                .id("live-hud-top")

                            topBar
                                .padding(.top, topPadding)

                            speedHero
                            metricGrid
                            lowerMetrics

                            if isInlineMode {
                                InlineLiveMetricsView(accentColor: accentColor)
                            }
                        }
                        .padding(.horizontal, horizontalPadding)
                        .padding(.bottom, dockHeight + bottomPadding)
                        .frame(maxWidth: .infinity, alignment: .top)
                        .frame(minHeight: proxy.size.height, alignment: .top)
                    }
                    .frame(width: proxy.size.width, height: proxy.size.height)
                    .scrollBounceBehavior(.basedOnSize)
                    .onAppear {
                        reader.scrollTo("live-hud-top", anchor: .top)
                    }
                    .onChange(of: sessionRecording.state.status) { _, status in
                        if status == .preparing || status == .recording {
                            reader.scrollTo("live-hud-top", anchor: .top)
                        }
                    }
                }

                controlDock(bottomPadding: bottomPadding, horizontalPadding: horizontalPadding)
            }
            .frame(width: proxy.size.width, height: proxy.size.height)
        }
        .background(SkateTrackSessionStartColors.navy.ignoresSafeArea())
        .preferredColorScheme(.dark)
        .toolbar(.hidden, for: .navigationBar)
        .accessibilityIdentifier("live-hud-view")
    }

    private var liveBackground: some View {
        ZStack {
            LinearGradient(
                colors: [
                    SkateTrackSessionStartColors.navy3,
                    SkateTrackSessionStartColors.navy2,
                    SkateTrackSessionStartColors.navy
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            MiniRouteMapView(
                coordinates: sessionRecording.state.recentRouteCoordinates,
                accentColor: accentColor
            )
            .opacity(0.34)
            .blur(radius: 0.2)
            .scaleEffect(1.08)
            .allowsHitTesting(false)

            RadialGradient(
                colors: [accentColor.opacity(0.28), .clear],
                center: .topTrailing,
                startRadius: 20,
                endRadius: 420
            )

            diagonalSpeedLine
                .allowsHitTesting(false)
        }
    }

    private var diagonalSpeedLine: some View {
        GeometryReader { proxy in
            Path { path in
                path.move(to: CGPoint(x: proxy.size.width * 0.18, y: proxy.size.height * 0.72))
                path.addLine(to: CGPoint(x: proxy.size.width * 0.78, y: proxy.size.height * 0.04))
            }
            .stroke(accentColor.opacity(0.70), style: StrokeStyle(lineWidth: 5, lineCap: .round))
            .shadow(color: accentColor.opacity(0.45), radius: 12)
        }
    }

    private func controlDock(bottomPadding: CGFloat, horizontalPadding: CGFloat) -> some View {
        HStack(spacing: 10) {
            pauseResumeButton
            SlideToEndSessionControl(
                accentColor: accentColor,
                isDisabled: !canControlActiveSession,
                onEnd: endSession
            )
        }
        .padding(.horizontal, horizontalPadding)
        .padding(.top, 18)
        .padding(.bottom, bottomPadding)
        .frame(maxWidth: .infinity)
        .background(controlDockBackground)
        .accessibilityIdentifier("live-hud-control-dock")
    }

    private var controlDockBackground: some View {
        LinearGradient(
            colors: [
                SkateTrackSessionStartColors.navy.opacity(0.0),
                SkateTrackSessionStartColors.navy.opacity(0.88),
                SkateTrackSessionStartColors.navy.opacity(1.0)
            ],
            startPoint: .top,
            endPoint: .bottom
        )
        .ignoresSafeArea(edges: .bottom)
    }

    private var topBar: some View {
        HStack(spacing: 10) {
            HStack(spacing: 7) {
                Circle()
                    .fill(statusDotColor)
                    .frame(width: 8, height: 8)
                Text(LocalizedStringKey(modeLocalizationKey))
                    .lineLimit(1)
                Text("·")
                Text(LocalizedStringKey(sessionRecording.state.status.localizationKey))
                    .lineLimit(1)
            }
            .tracking(1.1)
            .font(.system(size: 11, weight: .heavy, design: .monospaced))
            .foregroundStyle(.white)
            .padding(.horizontal, 12)
            .padding(.vertical, 9)
            .background(accentColor.opacity(0.88))
            .clipShape(Capsule())
            .accessibilityIdentifier("live-hud-status-badge")

            Spacer()

            Button(action: sosStubAction) {
                Text("session.hud.sos")
                    .font(.system(size: 12, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 13)
                    .padding(.vertical, 9)
                    .background(SkateTrackSessionStartColors.accent2.opacity(0.88))
                    .clipShape(Capsule())
            }
            .buttonStyle(.plain)
            .accessibilityIdentifier("live-hud-sos-button")
        }
    }

    private var speedHero: some View {
        VStack(spacing: 14) {
            LiveSpeedDisplayView(
                speedKilometersPerHour: sessionRecording.state.currentSpeedKilometersPerHour,
                maxSpeedKilometersPerHour: sessionRecording.state.maxSpeedKilometersPerHour,
                accentColor: accentColor
            )

            Text(LocalizedStringKey(modeLocalizationKey))
                .font(.system(size: 15, weight: .heavy, design: .rounded))
                .foregroundStyle(.white.opacity(0.92))
                .lineLimit(1)
                .padding(.horizontal, 14)
                .padding(.vertical, 9)
                .background(accentColor.opacity(0.16))
                .clipShape(Capsule())
                .overlay(Capsule().stroke(accentColor.opacity(0.26), lineWidth: 1))
        }
        .padding(.top, 4)
        .frame(maxWidth: .infinity)
        .accessibilityIdentifier("live-hud-speed-hero")
    }

    private var metricGrid: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                LiveHUDMetricCardView(
                    value: formattedDistance,
                    labelKey: "session.hud.distance",
                    tintColor: SkateTrackSessionStartColors.teal,
                    accessibilityID: "live-hud-distance"
                )
                LiveHUDMetricCardView(
                    value: formattedElapsedTime,
                    labelKey: "session.hud.time",
                    tintColor: SkateTrackSessionStartColors.amber,
                    accessibilityID: "live-hud-time"
                )
            }

            HStack(spacing: 10) {
                TiltIndicatorView(
                    tiltDegrees: sessionRecording.state.currentTiltDegrees,
                    accentColor: SkateTrackSessionStartColors.blueCold
                )
                LiveHUDMetricCardView(
                    value: "--",
                    labelKey: "session.hud.tricks",
                    tintColor: SkateTrackSessionStartColors.accent,
                    accessibilityID: "live-hud-tricks"
                )
            }
        }
    }

    private var lowerMetrics: some View {
        HStack(spacing: 10) {
            heartRateCard
            modeChip
        }
    }

    private var heartRateCard: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("--")
                .font(.system(size: 26, weight: .heavy, design: .rounded))
                .foregroundStyle(accentColor)
            Text("session.hud.heartRate")
                .tracking(1.2)
                .font(.system(size: 9, weight: .bold, design: .monospaced))
                .foregroundStyle(SkateTrackSessionStartColors.textTertiary)
                .textCase(.uppercase)
        }
        .frame(width: 88, alignment: .leading)
        .padding(12)
        .background(SkateTrackSessionStartColors.card.opacity(0.92))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(SkateTrackSessionStartColors.border, lineWidth: 1))
        .accessibilityIdentifier("live-hud-heart-rate")
    }

    @ViewBuilder
    private var liveModeIcon: some View {
        if isInlineMode {
            InlineSkateGlyphView(color: accentColor, size: 24)
        } else {
            Image(systemName: "figure.skateboarding")
                .foregroundStyle(accentColor)
        }
    }

    private var modeChip: some View {
        HStack(spacing: 8) {
            liveModeIcon
            Text(LocalizedStringKey(sessionRecording.state.selectedSportMode?.modeLocalizationKey ?? "session.hud.noMode"))
                .font(.system(size: 13, weight: .heavy, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
            Spacer()
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 16)
        .frame(maxWidth: .infinity)
        .background(accentColor.opacity(0.14))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(accentColor.opacity(0.24), lineWidth: 1))
        .accessibilityIdentifier("live-hud-mode-chip")
    }

    private var pauseResumeButton: some View {
        Button(action: pauseOrResume) {
            Image(systemName: sessionRecording.state.status == .paused ? "play.fill" : "pause.fill")
                .font(.system(size: 18, weight: .heavy))
                .foregroundStyle(.white)
                .frame(width: 62, height: 62)
                .background(SkateTrackSessionStartColors.card.opacity(canControlActiveSession ? 1.0 : 0.48))
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(SkateTrackSessionStartColors.border, lineWidth: 1))
        }
        .buttonStyle(.plain)
        .disabled(!canControlActiveSession)
        .accessibilityIdentifier("live-hud-pause-resume")
    }

    private var canControlActiveSession: Bool {
        sessionRecording.state.status == .recording || sessionRecording.state.status == .paused
    }

    private var accentColor: Color {
        guard let mode = sessionRecording.state.selectedSportMode else {
            return SkateTrackSessionStartColors.accent
        }
        switch mode {
        case .skateboard:
            return SkateTrackSessionStartColors.accent
        case .inline:
            return SkateTrackSessionStartColors.purple
        }
    }

    private var isInlineMode: Bool {
        if case .inline = sessionRecording.state.selectedSportMode { return true }
        return false
    }

    private var statusDotColor: Color {
        sessionRecording.state.status == .paused ? SkateTrackSessionStartColors.amber : SkateTrackSessionStartColors.teal
    }

    private var modeLocalizationKey: String {
        sessionRecording.state.selectedSportMode?.modeLocalizationKey ?? "session.hud.noMode"
    }

    private var formattedDistance: String {
        String(format: "%.1f", sessionRecording.state.distanceKilometers)
    }

    private var formattedElapsedTime: String {
        let totalSeconds = max(0, Int(sessionRecording.state.elapsedTime.rounded()))
        let minutes = totalSeconds / 60
        let seconds = totalSeconds % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }

    private func pauseOrResume() {
        Task {
            if sessionRecording.state.status == .paused {
                await sessionRecording.actions.resumeSession()
            } else {
                await sessionRecording.actions.pauseSession()
            }
        }
    }

    private func endSession() {
        Task {
            await sessionRecording.actions.requestEndSession()
        }
    }

    private func sosStubAction() {
        // Task-014 will replace this stub with Fall Alert / SOS flow routing.
    }
}

#Preview("Live HUD Mock") {
    LiveHUDView(sessionRecording: useSessionRecording(coordinator: .makeMockCoordinator()))
}
